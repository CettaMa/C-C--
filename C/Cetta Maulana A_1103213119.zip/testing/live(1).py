text=input("Masukan string : ")
i=1
for x in text:
    print(text[:i])
    i+=1