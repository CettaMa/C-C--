angka=int(input("Masukan angka 1-100 : "))

for x in range(1,angka):
    
    if (x%2==1):
        print(x,"\n")